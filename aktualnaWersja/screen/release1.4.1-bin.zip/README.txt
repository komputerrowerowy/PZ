TileDownloader by nickelliott.

TileDownloader is released under the GNU Public License (GPL).  The program and source code may be found at https://sourceforge.net/projects/tiledownloader/

Installation instructions:

Simply copy the tiledownloader.exe and the two WindowsAPICodePack files anywhere you want.  I would suggest putting them in their own folder in "Program files" or "Program files(x86)" (the latter if you are using a 64bit version of Windows).

Note that TileDownloader will save an xml file (TileServers.xml) containing details of the servers you use in the same directory that it is located in.

I'm afraid the calls to the WindowsAPICodePack will cause the program to crash under Windows XP - sorry about that.  I'm working on it..


Usage instructions:

The first time you run TileDownloader (in fact anytime it can't locate TileServers.xml), it will create a new set of server details for MapQuest, and save those settings to file.  You may add other OSM tile servers, and remove MapQuest from the list if you don't want to use it. (However you have to have at least one server in the list!)

To download an area of tiles, select the server you wish to use and the location on your computer you want to download the tiles to. Then either:

Use the slippy map - Pan/zoom to the approximate area you want, then hold <shift> whilst dragging a rectangle on the map.  Select the zoom levels you want.  TileDownloader will show you how many tiles your selection covers.  When ready, click download.  A new window will open, showing you the progress for this download.  You may select another area, and have multiple download operations going on concurrently.  You will get a pop-up window for each job.

Enter the X/Y coordinates - select the 2nd tab and enter the x/y coordinates and corresponding zoom level, then press Download to begin.

The update tab will, for every tile found in the directory specified in the "Download To.." textbox, check at the specified server when that tile was last redered.  If it has been rendered more recently than your local copy, it will be re-downloaded.  

Note:  Higher zoom levels are rendered on the fly, whereas low-zoom tiles are cached.  Tiledownloader used to check whether before downloading to confirm the online tile was more recent than the local copy.  However, that meant you had to force the high zoom tiles to be redrawn by panning around the map at each zoom level first.  Since the intent was to limit the load on the server and this actually doubled the workload (render the tile for you during the manual pan around, then render it again for the download) I changed TileDownloader's behaviour so that it only checks the timestamp of lower zoom tiles.

